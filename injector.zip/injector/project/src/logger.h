#pragma once

#ifdef DEBUG
#include <stdio.h>

#define log(...) printf("Injector | INFO: " __VA_ARGS__); printf("\n")
#define loge(...) printf("Injector | ERROR: " __VA_ARGS__); printf("\n")
#else
#define log(...)
#define loge(...)
#endif