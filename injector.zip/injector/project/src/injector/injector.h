#pragma once

#include <assert.h>
#include <string>
#include <unistd.h>
#include <cstdint>
#include <filesystem>
#include <random>
#include <algorithm>
#include <sys/stat.h>
#include <sys/sysctl.h>
#include "../logger.h"

extern "C" {
#include "ct_bypass/ct_bypass.h"
#include "opainject/opainject.h"
}

namespace fs = std::__fs::filesystem;

namespace injector {
    class dylib {
    private:
        fs::path path;
        std::string process;

    public:
        dylib(const std::string &_path) : path(_path) {
            assert(access(path.c_str(), F_OK) == 0);
        }

        int prepare(const std::string &app_name);
        int inject();
    };
}