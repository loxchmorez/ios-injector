#pragma once

#include <sys/types.h>

int inject_dylib(pid_t pid, char *path);