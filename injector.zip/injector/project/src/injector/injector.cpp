#include "injector.h"

namespace injector {
    std::string get_team_id(const std::string &appstore_binary) {
        char *team_id = extract_team_id((char *)appstore_binary.data());
        if(!team_id) return "";
        
        std::string ret = std::string(team_id);
        free(team_id);
        
        return ret;
    }
    
    pid_t pid_for_name(const std::string &process_name) {
        int mib[4] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
        size_t size;
        struct kinfo_proc *info;
        
        sysctl(mib, 4, NULL, &size, NULL, 0);
        info = (struct kinfo_proc *)malloc(size);
        sysctl(mib, 4, info, &size, NULL, 0);
        
        pid_t pid = -1;
        size_t count = size / sizeof(struct kinfo_proc);
        for(size_t i = 0; i < count; i++) {
            if(strcmp(info[i].kp_proc.p_comm, process_name.c_str()) == 0) {
                pid = info[i].kp_proc.p_pid;
                free(info);
                break;
            }
        }
                
        if(pid < 0) free(info);
        
        return pid;
    }
    
    int dylib::prepare(const std::string &app_name) {
        log("Preparing dylib for injecting");
        std::string temp_dir_template = "/var/containers/Bundle/Application/.temp-XXXXXXXXXX";
        char *temp_dir = mkdtemp(&temp_dir_template[0]);
        if (!temp_dir) {
            return -1;
        }
        
        log("Created temp working directory at: %s", temp_dir);
        
        int mr = chmod(temp_dir, 0755);
        if (mr != 0) {
            return -2000 + mr;
        }
        
        log("Executed chmod");
        
        int wr = chown(temp_dir, 0, 0);
        if (wr != 0) {
            return -3000 + wr;
        }
        
        log("Executed chown");
        
        fs::path dest_path = fs::path(temp_dir) / this->path.filename();
        try {
            fs::copy_file(this->path, dest_path, fs::copy_options::overwrite_existing);
            this->path = dest_path;
        } catch (const fs::filesystem_error& e) {
            return -4;
        }
        
        log("Copied target dylib");
        
        fs::path apps = "/var/containers/Bundle/Application";
        std::string app_path;
        try {
            for (const auto& entry : fs::directory_iterator(apps)) {
                fs::path bundle = entry.path() / (app_name + ".app");
                if(fs::is_directory(bundle)) {
                    std::string binary = bundle / app_name;
                    if(fs::exists(binary)) {
                        app_path = binary;
                        break;
                    }
                }
            }
        } catch (const fs::filesystem_error& e) {
            return -5;
        }
        
        if(app_path.empty()) {
            return -6;
        }
        
        log("Found target app binary");
        
        std::string team_id = get_team_id(app_path);
        if(team_id.empty()) {
            return -7;
        }
        
        log("Extracted team ID: %s", team_id.c_str());
        
        if (sign_macho(this->path.c_str(), (char *)team_id.data()) != 0) {
            fs::remove(temp_dir);
            return -8;
        }
        
        log("Signed dylib. Preparation done");

        this->process = app_name;
        
        return 0;
    }

    int dylib::inject() {
        pid_t pid = pid_for_name(this->process);
        return inject_dylib(pid, (char *)this->path.string().data());
    }
}