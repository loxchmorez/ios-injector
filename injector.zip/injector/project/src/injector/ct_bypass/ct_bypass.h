#pragma once

/**
 * @brief Applies CoreTrust bypass to a Mach-O file
 * 
 * @param macho_path Path to the Mach-O file to process
 * @param team_id Team ID to use for signing (can be nullptr to use default)
 * @return 0 on success, negative value on error
 */
int sign_macho(const char *macho_path, char *team_id);

char *extract_team_id(char *appstore_binary);