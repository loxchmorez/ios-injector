#import "delegate.h"
#import "view_controller.h"

@implementation delegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
	self.root_view_controller = [[view_controller alloc] init];
	self.window.rootViewController = self.root_view_controller;
	[self.window makeKeyAndVisible];

	return YES;
}
@end
