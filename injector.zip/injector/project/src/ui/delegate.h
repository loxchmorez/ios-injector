#import <UIKit/UIKit.h>

@interface delegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) UIViewController* root_view_controller;

@end
