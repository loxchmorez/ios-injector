#import <UIKit/UIKit.h>

@interface view_controller : UIViewController

@property (nonatomic, strong) UILabel *label;
@property (nonatomic, strong) UIButton *button;

@property (strong, nonatomic) UITextField *process;
@property (strong, nonatomic) UITextField *path;

@end
