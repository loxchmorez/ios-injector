#import "view_controller.h"
#import <AVFoundation/AVFoundation.h>
#include "../injector/injector.h"
#include <unistd.h>

@interface view_controller ()
@end

@implementation view_controller

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setupUI];
}

- (void)setupUI {
    // Label
    self.label = [[UILabel alloc] init];
    self.label.text = [NSString stringWithFormat:@"metaware.space injector by rain | status: idle"];
    self.label.textColor = [UIColor blackColor];
    self.label.textAlignment = NSTextAlignmentCenter;
    self.label.numberOfLines = 0;
    self.label.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.label];
    
    // Process TextField
    self.process = [[UITextField alloc] init];
    self.process.placeholder = @"process name";
    self.process.borderStyle = UITextBorderStyleRoundedRect;
    self.process.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.process];
    
    // Path TextField
    self.path = [[UITextField alloc] init];
    self.path.placeholder = @"/path/to/dylib";
    self.path.borderStyle = UITextBorderStyleRoundedRect;
    self.path.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:self.path];
    
    // Submit Button
    UIButton *submitButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [submitButton setTitle:@"Inject" forState:UIControlStateNormal];
    [submitButton addTarget:self action:@selector(inject) forControlEvents:UIControlEventTouchUpInside];
    submitButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:submitButton];
    
    // Constraints
    NSDictionary *views = @{
        @"label": self.label,
        @"process": self.process,
        @"path": self.path,
        @"button": submitButton
    };
    
    NSDictionary *metrics = @{
        @"margin": @20,
        @"fieldHeight": @40,
        @"verticalSpacing": @30
    };
    
    // Horizontal constraints
    for (UIView *view in @[self.label, self.process, self.path, submitButton]) {
        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-margin-[view]-margin-|"
                                                                        options:0
                                                                        metrics:metrics
                                                                          views:@{@"view": view}]];
    }
    
    // Vecrtical constraints
    [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-80-[label]-verticalSpacing-[process(fieldHeight)]-verticalSpacing-[path(fieldHeight)]-verticalSpacing-[button(fieldHeight)]"
                                                                     options:0
                                                                     metrics:metrics
                                                                       views:views]];
}

- (void)update_status:(NSString * )text {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.label.text = [NSString stringWithFormat:@"metaware.space injector by rain | status: %@", text];
    });
}

- (void)inject {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [self update_status:@"Starting"];
        
        const char *dylib = self.path.text.UTF8String;
        const char *process = self.process.text.UTF8String;
        
        injector::dylib lib = injector::dylib(dylib);
        [self update_status:@"Initialized dylib. Now signing"];
        
        int ret = lib.prepare(process);
        if(ret != 0) {
            [self update_status:[NSString stringWithFormat:@"An error occurred while signing. Code %d", ret]];
            return;
        }
        
        [self update_status:@"Signed dylib. Injecting..."];
        ret = lib.inject();
        
        if(ret != 0) {
            [self update_status:[NSString stringWithFormat:@"An error occurred while injecting. Code %d", ret]];
            return;
        }
        
        [self update_status:[NSString stringWithFormat:@"Successfully injected %@ into %s", [[NSString stringWithUTF8String:dylib] lastPathComponent], process]];
    });
}

@end
