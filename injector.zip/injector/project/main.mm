#import <Foundation/Foundation.h>
#import <unistd.h>
#import <assert.h>
#import "src/ui/delegate.h"
#import "src/injector/injector.h"
#import "src/logger.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        log("App started");
        setuid(0);
        seteuid(0);
        setgid(0);
        setegid(0);
        
        return UIApplicationMain(argc, argv, nil, NSStringFromClass(delegate.class));
    }
}
